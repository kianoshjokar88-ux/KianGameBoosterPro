package com.kian.gamebooster

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(22), dp(24), dp(22), dp(24))
            setBackgroundColor(0xFF101522.toInt())
        }

        fun text(value: String, size: Float, color: Int, bold: Boolean = false) =
            TextView(this).apply {
                text = value
                textSize = size
                setTextColor(color)
                gravity = Gravity.CENTER
                if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
                setPadding(0, dp(8), 0, dp(8))
            }

        root.addView(text("🎮", 52f, 0xFFFFFFFF.toInt(), true))
        root.addView(text("KIAN GAME BOOSTER PRO", 22f, 0xFF66E3FF.toInt(), true))
        root.addView(text("REDMI 13  •  CALL OF DUTY MOBILE", 12f, 0xFFB8C5D6.toInt()))

        root.addView(text(
            "با روشن‌کردن حالت بازی، اعلان دائمی نمایش داده می‌شود.\n" +
            "می‌توانی از صفحه برنامه خارج شوی؛ اعلان تا وقتی خودت خاموشش نکنی باقی می‌ماند.",
            15f, 0xFFFFFFFF.toInt()
        ))

        val on = Button(this).apply {
            text = "روشن کردن حالت بازی"
            isAllCaps = false
            textSize = 16f
            setOnClickListener { enableBooster() }
        }
        root.addView(on, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(54)
        ))

        val off = Button(this).apply {
            text = "خاموش کردن حالت بازی"
            isAllCaps = false
            textSize = 16f
            setOnClickListener {
                stopService(Intent(this@MainActivity, BoosterService::class.java))
                Toast.makeText(this@MainActivity, "حالت بازی خاموش شد", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(off, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(54)
        ))

        root.addView(text(
            "تنظیم پیشنهادی کالاف: گرافیک Low، فریم‌ریت روی بالاترین گزینه پایدار، " +
            "Battery Saver خاموش و Game Turbo روشن.\n\n" +
            "این برنامه اعلان و وضعیت حالت بازی را نگه می‌دارد؛ اندروید اجازه نمی‌دهد " +
            "یک اپ معمولی CPU/GPU را به‌زور روی حداکثر قفل کند یا محدودیت دما را دور بزند.",
            12f, 0xFFFFD18A.toInt()
        ))

        setContentView(root)
    }

    private fun enableBooster() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 71)
            return
        }
        startBoosterService()
    }

    private fun startBoosterService() {
        val intent = Intent(this, BoosterService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
        else startService(intent)
        Toast.makeText(this, "حالت بازی روشن شد", Toast.LENGTH_SHORT).show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 71) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startBoosterService()
            } else {
                Toast.makeText(this, "برای دیدن اعلان، اجازه اعلان را فعال کن", Toast.LENGTH_LONG).show()
            }
        }
    }
}
